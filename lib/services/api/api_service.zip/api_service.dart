import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  final String baseUrl = 'http://10.10.245.30:45455/api/v1'; //utk local dgn visual studio
  // final String baseUrl = 'https://sindangheula.higertech.com/api/v1';

  final String username = 'sindangheula';
  final String password = 'ZoGBHm1hzbWCBzq';

  String _basicAuth() {
    final String credentials = '$username:$password';
    return 'Basic ' + base64Encode(utf8.encode(credentials));
  }

  Future<http.Response> get(String endpoint) async {
    final response = await http.get(
      Uri.parse('$baseUrl/$endpoint'),
      headers: {
        'Authorization': _basicAuth(),
      },
    );
    return response;
  }

  Future<http.Response> post(String endpoint, dynamic body) async {
    final response = await http.post(
      Uri.parse('$baseUrl/$endpoint'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': _basicAuth(),
      },
      body: jsonEncode(body),
    );
    return response;
  }

  Future<http.Response> put(String endpoint, dynamic body) async {
    final response = await http.put(
      Uri.parse('$baseUrl/$endpoint'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': _basicAuth(),
      },
      body: jsonEncode(body),
    );
    return response;
  }

  Future<http.Response> delete(String endpoint) async {
    final response = await http.delete(
      Uri.parse('$baseUrl/$endpoint'),
      headers: {
        'Authorization': _basicAuth(),
      },
    );
    return response;
  }
}
